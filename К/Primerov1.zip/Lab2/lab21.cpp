#ifdef DBL
typedef double real;
#else
typedef float real;
#endif

#include<cstdlib>
#include<iostream>
#include<iomanip>
#include <omp.h>

using namespace std; 

// gamma=\sum x_i, x_{N}, N=N*M.

int main(int argc, char *argv[])
{
    int M = atoi(argv[1]);
    int N = atoi(argv[2]);
    int v = atoi(argv[3]);

    cout << "M=" << M << "\tN=" << N << "\tv=" << v << endl;
    N=N*M;

    real *x;
    real beta= v*1.e-1, gamma; 
    double begin=0, end=0;

    x = new real [N];
    
begin = omp_get_wtime();

    for(int i=0;i<N;i++){
	    x[i]=beta;
    }

    for(int i=0;i<N;i++){
	    gamma=x[i];
    }
    
end = omp_get_wtime();

cout << setprecision(3) << "B=" << ((2*N*sizeof(real))*1e-9)/(end-begin) << " Gbyte/s\n";

//    printf("%.12f %.18f\n",(float)0.2,(double)0.2);

begin = omp_get_wtime();
    gamma=0;
    #pragma GCC unroll 1
    for(int i=0;i<N;i++){
	gamma+=x[i];
    }
end = omp_get_wtime();
cout << "unroll 1\n";
cout << setprecision(3) << "I=" << 1.0*N/(2*N*sizeof(real)) << " FLOP/byte\n";
cout << setprecision(3) << "P=" << (1.0*N*1e-9)/(end-begin) << " GFLOP/s\n";
cout << setprecision(3) << "T=" << (end-begin) << " s\n";
cout << setprecision(3) << "gamma=" << gamma << " s\n";

begin = omp_get_wtime();
    gamma=0;
    #pragma GCC unroll 2
    for(int i=0;i<N;i++){
	gamma+=x[i];
    }
end = omp_get_wtime();
cout << "unroll 2\n";
cout << setprecision(3) << "I=" << 1.0*N/(2*N*sizeof(real)) << " FLOP/byte\n";
cout << setprecision(3) << "P=" << (1.0*N*1e-9)/(end-begin) << " GFLOP/s\n";
cout << setprecision(3) << "T=" << (end-begin) << " s\n";
cout << setprecision(3) << "gamma=" << gamma << " s\n";

begin = omp_get_wtime();
    gamma=0;
    #pragma GCC unroll 3
    for(int i=0;i<N;i++){
	gamma+=x[i];
    }
end = omp_get_wtime();
cout << "unroll 3\n";
cout << setprecision(3) << "I=" << 1.0*N/(2*N*sizeof(real)) << " FLOP/byte\n";
cout << setprecision(3) << "P=" << (1.0*N*1e-9)/(end-begin) << " GFLOP/s\n";
cout << setprecision(3) << "T=" << (end-begin) << " s\n";
cout << setprecision(3) << "gamma=" << gamma << " s\n";

begin = omp_get_wtime();
    gamma=0;
    #pragma GCC unroll 4
    for(int i=0;i<N;i++){
	gamma+=x[i];
    }
end = omp_get_wtime();
cout << "unroll 4\n";
cout << setprecision(3) << "I=" << 1.0*N/(2*N*sizeof(real)) << " FLOP/byte\n";
cout << setprecision(3) << "P=" << (1.0*N*1e-9)/(end-begin) << " GFLOP/s\n";
cout << setprecision(3) << "T=" << (end-begin) << " s\n";
cout << setprecision(3) << "gamma=" << gamma << " s\n";

    delete [] x;  
    return 0;
}
