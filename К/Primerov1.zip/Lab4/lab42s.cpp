#include <iostream>
#include <iomanip>
#include <omp.h>
#include <mpi.h>
#include <cmath>
 
using namespace std;
 
const int Nit=1;
 
typedef float real;
 
int main(int argc, char *argv[])
{
    double t1,t2,tp;
    int pid, np, mi;
    MPI_Comm world=MPI_COMM_WORLD;
    MPI_Status *status;
    real *A,*B,*C,*Ai,*Bi,*Ci;


int M=atoi(argv[1]);
int N=atoi(argv[2]);
int v=atoi(argv[3]);


MPI_Init(&argc,&argv);
MPI_Comm_rank(MPI_COMM_WORLD,&pid);
MPI_Comm_size(MPI_COMM_WORLD,&np);

if(!pid)
{
    A= new real[M*N];
    B= new real[N*M];
    C= new real[M*M];

    real alpha=1.01*v, beta=0.002*v;

    for(int i=0;i<M;i++)
        for(int j=0;j<N;j++) A[i*N+j]=alpha;

    for(int i=0;i<N;i++)
        for(int j=0;j<M;j++) B[i*M+j]=beta;


t1=MPI_Wtime();

    for(int i=1;i<np;i++){
	    MPI_Send(&M,1,MPI_INT,i,0,world);
	    MPI_Send(&N,1,MPI_INT,i,0,world);

	    MPI_Send(A+(M/np)*N*i,(M/np)*N,MPI_FLOAT,i,0,world);
	    MPI_Send(B,N*M,MPI_FLOAT,i,0,world);
    }

    Ci=C; Ai=A; Bi=B;
}
else
{
	MPI_Recv(&M,1,MPI_INT,0,0,world,status);
	MPI_Recv(&N,1,MPI_INT,0,0,world,status);

        Ai = new real[(M/np)*N];
	MPI_Recv(Ai,(M/np)*N,MPI_FLOAT,0,0,world,status);

	Bi = new real[N*M];
	MPI_Recv(Bi,N*M,MPI_FLOAT,0,0,world,status);

	Ci = new real[(M/np)*M];
}

 mi=M/np;

real tmp;

    for(int i=0;i<mi;i++)
        for(int j=0;j<M;j++){
	    tmp=0;
	    for(int k=0;k<N;k++) tmp+=Ai[i*N+k]*Bi[k*M+j];
	    Ci[i*M+j]=tmp;
	}

if(!pid){
    for(int i=1;i<np;i++){
	MPI_Recv(C+mi*M*i,mi*M,MPI_FLOAT,i,0,world,status);
    }
}
else{
	MPI_Send(Ci,mi*M,MPI_FLOAT,0,0,world);
	delete [] Ai; delete [] Bi; delete [] Ci;
}


if(!pid){
    t2=MPI_Wtime();
    tp=(t2-t1)/Nit;
    cout << setprecision(3) << "M: "<< M << "\tN: " << N  << endl;
    cout << setprecision(3) << "p: "<< np << "\tT"<< np  << ": " << tp <<"s" << endl;

    delete [] A; delete [] B; delete [] C;
  }      

MPI_Finalize();
return 0;
}
